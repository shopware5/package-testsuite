// Set Browser language to german
user_pref("browser.search.countryCode", "DE");
user_pref("browser.search.region", "DE");
user_pref("general.useragent.locale", "de");
user_pref("intl.locale.matchOS", false);
user_pref("intl.accept_languages", "de-DE, de");

// Prevent automatic addition of www/com to urls
user_pref("browser.fixup.alternate.enabled", false);

// Prevent FF Update dialogs
user_pref("app.update.auto", false);
user_pref("app.update.enabled", false);
user_pref("app.update.silent", false);